# docker-netflix-global-config-server
Global config server for Fleetman, using Netflix OSS Stack and Docker.
